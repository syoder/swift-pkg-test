//
//  FlyBuy
//
//  Copyright © 2019 Radius Networks. All rights reserved. See LICENSE for
//  details.
//

#import <UIKit/UIKit.h>

//! Project version number for FlyBuySDK.
FOUNDATION_EXPORT double FlyBuySDKVersionNumber;

//! Project version string for FlyBuySDK.
FOUNDATION_EXPORT const unsigned char FlyBuySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FlyBuySDK/PublicHeader.h>


